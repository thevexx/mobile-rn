import React from 'react';
//Pull in AppNavigator from the navigation folder
import AppNavigator from './navigation/AppNavigator'

export default function App() {
  return (
    <AppNavigator /> 
  );
}